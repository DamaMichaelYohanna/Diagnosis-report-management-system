from django.db import models


class TestReport(models.Model):
    test_id = models.CharField(max_length=50, null=True)
    patient_name = models.CharField(max_length=50, null=True)
    date = models.DateField(auto_created=True, null=True)
    choice = (('malaria', 'malaria'), ('typhoid', 'typhoid'), ('hiv', 'hiv'),
              ('gonorrhea', 'gonorrhea'), ('hepatitis', 'hepatitis'))
    category = models.CharField(max_length=50, choices=choice)
    result = models.CharField(max_length=10, choices=(('positive', 'positive'),
                                                      ('negative', 'negative'))
                              )
    phone = models.IntegerField(null=True)
    passport = models.ImageField(null=True)

#
#
# class Malaria(TestInfo):
#     PBS_time_consume = models.CharField(max_length=50)
#     PBS_cost_per_test = models.CharField(max_length=50)
#     PBS_expertise_required = models.CharField(max_length=50)
#     PBS_subjective_error = models.CharField(max_length=50)
#     PBS_labour_intensive = models.CharField(max_length=50)
#     PBS_therapeutic_mon = models.CharField(max_length=50)
#     PBS_mix_infection = models.CharField(max_length=50)
#     PBS_storage_of_cons = models.CharField(max_length=50)
#     PBS_field_application = models.CharField(max_length=50)
#     OptiMAL_time_consume = models.CharField(max_length=50)
#     OptiMAL_cost_per_test = models.CharField(max_length=50)
#     OptiMAL_expertise_required = models.CharField(max_length=50)
#     OptiMAL_subjective_error = models.CharField(max_length=50)
#     OptiMAL_labour_intensive = models.CharField(max_length=50)
#     OptiMAL_therapeutic_mon = models.CharField(max_length=50)
#     OptiMAL_mix_infection = models.CharField(max_length=50)
#     OptiMAL_storage_of_cons = models.CharField(max_length=50)
#     OptiMAL_field_application = models.CharField(max_length=50)
#     PCR_time_consume = models.CharField(max_length=50)
#     PCR_cost_per_test = models.CharField(max_length=50)
#     PCR_expertise_required = models.CharField(max_length=50)
#     PCR_subjective_error = models.CharField(max_length=50)
#     PCR_labour_intensive = models.CharField(max_length=50)
#     PCR_therapeutic_mon = models.CharField(max_length=50)
#     PCR_mix_infection = models.CharField(max_length=50)
#     PCR_storage_of_cons = models.CharField(max_length=50)
#     PCR_field_application = models.CharField(max_length=50)
#
#     pass
#
#
# class Typhoid(TestInfo):
#     pass
#
#
# class Hiv(TestInfo):
#     pass
#
#
# class Gonorhea(TestInfo):
#     pass
#
#
# class Hypertitis(TestInfo):
#     pass
#
