from datetime import timezone
import datetime

from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.db.models import Q
from django.shortcuts import render, redirect

from main.forms import TestReportForm
from main import models


class Logout(LogoutView):
    template_name = 'logout.html'


class Login(LoginView):
    template_name = 'login.html'
    success_url = '/'


@login_required
def index(request):
    context = {'home_section': 'active'}
    return render(request, 'index.html', context=context)


@login_required
def all_records(request):
    TODAY = str(datetime.date.today())
    PAST_SEVEN_DAYS = str(datetime.date.today() - datetime.timedelta(days=7))[:10]
    THIS_MONTH = None
    THIS_YEAR = None
    if request.method == 'POST':
        value = request.POST.get('search')
        if value:
            if value == 'all':
                query_set = models.TestReport.objects.all()
            else:
                query_set = models.TestReport.objects.filter(category__icontains=value)
            # query_set_1 = models.Malaria.objects.all()
            # query_set_2 = models.Typhoid.objects.all()
            # query_set_3 = models.Hypertitis.objects.all()
            # if value == 'malaria':
            #     print('value is malaria')
            #     print(query_set_1)
            #     general_query_set = query_set_1
            # elif value == 'typhoid':
            #     general_query_set = query_set_2
            # elif value == 'hypatitis':
            #     general_query_set = query_set_3
            # else:
            #     general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)

        else:
            query_set = []
            print('not search parameter was send to server')

        context = {'result_section': 'active', 'test_results': query_set}
        return render(request, 'all_record.html', context)
    else:
        response = request.GET.get('date')
        if response:  # if an option selected,
            if response == 'any':  # if all, return all products
                query_set = models.TestReport.objects.all()
                # query_set_1 = models.Malaria.objects.all()
                # query_set_2 = models.Typhoid.objects.all()
                # query_set_3 = models.Hypertitis.objects.all()
                # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
                filters = 'any'
            elif response == 'today':  # if other choice, perform the query directly
                query_set = models.TestReport.objects.filter(date=TODAY)
                # query_set_1 = models.Malaria.objects.filter(date=TODAY)
                # query_set_2 = models.Typhoid.objects.filter(date=TODAY)
                # query_set_3 = models.Hypertitis.objects.filter(date=TODAY)
                # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
                filters = 'today'
            elif response == 'seven':  # if other choice, perform the query directly
                query_set = models.TestReport.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_1 = models.Malaria.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_2 = models.Typhoid.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_3 = models.Hypertitis.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
                filters = 'seven days'
            elif response == 'month':  # if other choice, perform the query directly
                query_set = models.TestReport.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_1 = models.Malaria.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_2 = models.Typhoid.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_3 = models.Hypertitis.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
                filters = 'this month'
            elif response == 'year':  # if other choice, perform the query directly
                query_set = models.TestReport.objects.filter(date__gt=PAST_SEVEN_DAYS)
                # query_set_1 = models.Malaria.objects.filter(date__icontains=str(timezone.now().year))
                # query_set_2 = models.Typhoid.objects.filter(date__icontains=str(timezone.now().year))
                # query_set_3 = models.Hypertitis.objects.filter(date__icontains=str(timezone.now().year))
                # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
                filters = 'this year'

        else:  # if response is empty just return all product
            query_set = models.TestReport.objects.all()
            # query_set_1 = models.Malaria.objects.all()
            # query_set_2 = models.Typhoid.objects.all()
            # query_set_3 = models.Hypertitis.objects.all()
            # general_query_set = list(query_set_3) + list(query_set_2) + list(query_set_1)
            # print(general_query_set)
            filters = 'any'

        context = {'result_section': 'active', 'test_results': query_set,
                   'filter': filters}
    # context = {'test_results':records}
    return render(request, 'all_record.html', context=context)


@login_required
def add_record(request):
    if request.method == 'POST':
        malaria_form = TestReportForm(request.POST, request.FILES)
        if malaria_form.is_valid():
            malaria_form.save()
            return redirect('/record/all')
    else:
        malaria_form = TestReportForm()
    context = {'form': malaria_form, 'add_section': 'active'}
    return render(request, 'add_record.html', context=context)


@login_required
def update_record(request, pk):
    report = models.TestReport.objects.get(pk=pk)
    if request.method == 'POST':
        malaria_form = TestReportForm(request.POST, request.FILES, instance=report)
        if malaria_form.is_valid():
            malaria_form.save()
            return redirect('/record/all')
    else:
        malaria_form = TestReportForm(instance=report)
    context = {'form': malaria_form, 'pk': pk}
    return render(request, 'update.html', context=context)


@login_required
def delete_record(request, pk):
    report = models.TestReport.objects.get(pk=pk).delete()
    return redirect('/record/all')


@login_required
def search(request):
    if request.method == 'POST':
        key_word = request.POST.get('search')
        report = models.TestReport.objects.filter(
            Q(test_id__icontains=key_word) | Q(patient_name__icontains=key_word)
        )
        print(report)
        context = {'result_section': 'active', 'test_results': report}
        return render(request, 'all_record.html', context=context)
