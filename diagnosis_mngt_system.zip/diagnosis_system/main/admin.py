from django.contrib import admin

from main.models import TestReport

admin.site.register(TestReport)
