from django.urls import path

from main import views

urlpatterns = [
    path('login/', views.Login.as_view(), name='login'),
    path('logout/', views.Logout.as_view(), name='logout'),
    path('', views.index, name='home'),
    path('record/all', views.all_records, name='all record'),
    path('record/add', views.add_record, name='add record'),
    path('record/update/<int:pk>', views.update_record, name='update record'),
    path('record/delete/<int:pk>', views.delete_record, name='delete record'),
    path('record/search', views.search, name='record search'),
]