from django import forms

from main.models import TestReport


class TestReportForm(forms.ModelForm):
    class Meta:
        model = TestReport
        fields = '__all__'
